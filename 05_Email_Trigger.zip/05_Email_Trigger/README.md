# Workflow to be triggered by an incoming email
This lab talks about triggering a workflow using an incoming email.

# Table of Contents
*  Email Triggering

# Tasks
1.  Trigger the workflow on an inbound email

# Using What you Know

1.  Create or identify an email account that could be used as a triggering account.
2.  Create or use an existing workflow.

# Email Triggering

1.  We want to add an email trigger to an existing or new workflow
2.  Create a target of type `POP3 Endpoint` and set it to `pop.gmail.com`. The port is `995`. 
3.  Create a new user and use username as `sxotelconet01@gmail.com` and password as `Cisco.123`. 
4.  Check both `TLS` and `Ignore`. Save the target.
5.  Now go to `Events and Webhooks` and click `NEW EVENT`
6.  Select an `Email Event` and give it a display name.
7.  Select the `TARGET ID` you just created
8.  Under `Criteria`, under `CONDITIONS`, click `ADD`. For `LEFT OPERAND` use the variable reference to insert the Sender of the email event.
9.  For `OPERATOR` select `Matches Wildcard` and then for the `RIGHT OPERAND` put in `sxo` and save the event.
10.  Send an email to `sxotelconet01@gmail.com`, did it trigger? Why or why not? How do you know?
11.  Go back to your workflow and click `ADD` under triggers. Change the `Type` to `Event` and pick your email event. Save, and validate the workflow.
12.  Send an email again. Did your workflow trigger? How do you know?
13.  Spend 20-30 minutes and come up with some additional things to add to this workflow. Use anything you've learned so far and explore!
