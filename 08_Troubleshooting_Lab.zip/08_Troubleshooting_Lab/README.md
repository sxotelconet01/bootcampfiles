# Troubleshooting Lab
This lab will take you through multiple activities 

# Table of Contents
*  Troubleshooting 

# Tasks
1. Import a workflow
2. Execute and troubleshoot

# Use Terminal Adapter to Login to your NFS Server
1. Import a workflow provided by the instructor.
2. Assign the right targets where needed.
3. Enter any default variable values for the workflow.
4. Execute the workflow, identify the errors and troubleshoot.
5. Correct the errors and run again.
6. Continue the process untill the whole workflow executes without any errors and completely successfully.

