# Advanced Workflow Authoring Lab

This lab will take you through some more advanced concepts in workflow authoring in AO. The assumption will be after you do a task in AO that you will understand how to do it
going forward. So when new tasks or concepts are introduced, they will be closely detailed. If you have to do that same tasks again later it will not. Anything from
the basic workflow authoring lab will not be recovered. 

# Table of Contents
*  Using What You Know
*  Get some Data and make a table
*  Loops and Results
*  Email Triggering and more

# Tasks
1.  Get some data from an API
2.  Read the data into a table format
3.  Loop through the Data
4.  Run conditionals to build out information from the data
5.  Show the Data
6.  Trigger the workflow on an inbound email

# Using What you Know
1.  Create a new workflow called `Advanced Workflow Lab`
2.  Add it to your category
3.  Create some variables! A string for output called `list_of_users_ids`. A local integer called `LVC`. A couple of local strings temporary strings. A local integer called `TRUE`, set it to `1`.
4.  Can you validate this workflow? Why or why not? Why is group not editable? 

# Get some Data and make a table
1.  Make a call to JSONPath Holder again accessing the `/posts` endpoint. It should be a `GET`
2.  Best way to do this? Can you build it with just a `http request` activity?
3.  On your workflow, click `ADD VARIABLE` under `Variables`, under `Data Type` click `ADD NEW`
4.  `Table Type` will be selected as it is the only advanced data type currently supported. Give your table a `DISPLAY NAME`. This table is just for show, we won't use it.
5.  Go to your `COLUMNS` and add fields via `ADD 1 MORE FIELD` at the bottom. The `FIELD NAME` is the column name, the `FIELD TITLE` is what is on the UI. You can select the type for the column in `FIELD TYPE` and add optional parameters.
6.  Add a few fields and make some required and some not via the `REQUIRED` slider. Click SAVE to save your table.
7.  Drag and drop a `Read Table from JSON` activity below your web call. 
8.  Under `Read Table`, set the `JSON PATH` to `$..table[*]` and check the `PERSIST TABLE` checkbox. If you do not check this, the data from the table will not be available to you later in the workflow.
9.  In `COLUMNS TO READ` click `ADD` to start adding columns. They should be all type `String` and their names should be `userId`, `id`, `title`, and `body`. Their names must match the JSON.
10.  Under `SOURCE JSON`, we need to "wrap" the web request json in some tags to make it readable, so we will put the output of the web activity into the `SOURCE JSON` field, but then wrap it as below
```json
    {
        "table": <reference to web call output>
    }
```
11.  Why do you believe we have to define the columns in step #9?
12.  Add a `PARALLEL BLOCK` to the top of the workflow
13.  Duplicate the API calls and `READ TABLE FROM JSON` so that each `BRANCH` has 1 API call and the subsequent table read
14.  Make the left `BRANCH` for /posts, the middle `BRANCH` for /users, and the right `BRANCH` for /comments. Each one of these is a separate endpoint that returns JSON table data
15.  Use [JSONPlace Holder Website](http://jsonplaceholder.typicode.com/) to see what each return will look like and map the correct columns in the tables. You should want to persist all data.

![JSONTable](readTableFrom_JSON.jpg)

# Loops and Results
1.  Drag and a drop `FOR EACH` Loop from the Logic area in the toolbox under your `Read Table from JSON` activity
2.  Click the insert variable refernce icon to load in the `SOURCE ARRAY`. What should it be?
3.  Drag and drop a `CONDTION BLOCK` inside the `FOR EACH` loop
4.  Set the `DISPLAY NAME` of the conditional to `If ID LIST is empty`
5.  Set the left `CONDITION BRANCH` to `THEN` and rigth one to `ELSE`
6.  On the left `CONDITON BRANCH` set the `CONDITION` to one of your local variables being empty or blank. We can do that by setting it to `Equals` then a blank field.
7.  On the right `CONDITION BRANCH` set the `CONDITION` to your local `TRUE` variable `Equals` to `1`. This is another way to do an `ELSE` statement. 
8.  In the left or empty branch, drag and drop a `SET VARIABLE` activity. 
9.  Set your local string variable to the current loop iterations id value. You do this via `Activities->For Each Loop->Source Array->Items->id`. Then click SAVE.
10.  On the right branch, drag and drop another `SET VARIABLE` activity, or duplicate the other one.
11.  Set your local string variable to itself, then a comma, and then the current loop iteration id value. This will build you a comma-delimited list of ids. 
12.  Can you build an infinite loop?
13.  How about looking at the table where ID=2, how do we do that?
14.  Create a new input variable called `user_to_look_for` that is `STRING`, set it to `1`. Drag and drop the `Select from Table` activity below your loop.
15.  Under `Select`, set the `INPUT TABLE` to the output of your `READ TABLE FROM JSONPATH` that reads the Posts data.
16.  Then set the `WHERE CLAUSE` to `userId=<your input value>'`. Persist this table as well and return all columns. 
17.  Drag and drop another `SELECT FROM TABLE` and use that one to filter the comments table where `postId=<input value>`
18.  Lastly, get one more `SELECT FROM TABLE` and filter the user table based on the input value as well. 
19.  Create an output `VARIABLE` called `results` and make it a string. Set it to `The user <user's name> has made <# of posts> posts and <# of comments> comments on our website!`
20.  Also set your output `VARIABLE` for the ID list to the list of IDs you generated in your loop 
21.  Validate, Run your workflow and see the results!
22.  Check out individual iterations of the loop. What other ways could you display results? What other things could you determine from this data?

![aoLoop](aoLoop.JPG)
