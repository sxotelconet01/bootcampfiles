# Terminal  Workflow Lab
This lab will take you through linux activities and put a focus on the terminal adatper as a primary vechicle. 
The target terminal server can be any terminal enabled CentOS based Linux system. This lab is written for CentOS 7.6+, but could be fit to any Linux setup.

# Table of Contents
*  Use a Terminal Target.
*  Create a workflow that uses linux activities and execute the workflow to observe the results.

# Tasks
1. Use Terminal Adapter to login to your GCP linux server
2. Use Terminal Adapter to run basic linux commands and install MySQL on your virtual machine.
3. Create a workflow with terminal activities.
4. Execute and observe the results.

# Use terminal activities  
1. We will install MySQL to our GCP Linux Server, we will use [this article](https://www.mysqltutorial.org/install-mysql/)
2. Either create new workflow or just edit the one you are using. Add a new group called `MySQL Install`
3. First we need to install RPM using apt-get. Drag and drop the `Execute Terminal Commmand(s)` activity and name as `Install RPMs`
Use the cmmand as `sudo yum install rpm -y`
4. Next we need to add the repos. Add an `Execute Terminal Commands(s)` activity, point it to your NFS server, and do the following commands: 
sudo rpm -Uvh https://repo.mysql.com/mysql80-community-release-el7-3.noarch.rpm
sudo sed -i 's/enabled=1/enabled=0/' /etc/yum.repos.d/mysql-community.repo
4.  Next we need to install MySQL via this command `sudo yum --enablerepo=mysql80-community install mysql-community-server`. So add that in a new terminal activity. This time we have to configure some more pieces.
5.  Since the install will prompt us for a y/n to download and install, we need to add a `User Response`. Click the Plus/Add under `User Response` and add a regex of `\[y[\/]{0,1}[d]{0,1}\/N\]:` with a response of `y`
6.  We also need to increase the default timeout as mysql might take a few moments to install, so increase the `Individual Command Timeout` to `900`. Also increase the `Activity Timeout` to the same.
7.  Now add a terminal activity to start your mySQL server via `service mysqld start` and then you can close off that group. A major benefit to the groups here is the ability to select `Skip Activity Execution` and basically comment out everything in that group and skip it. (we will use later)
8.  Next, we want to add a `MYSQL CONFIGURATION` group where we will handle setting up our root password, so let's add that group and some variables.
9.  Add an input called `I_root_password` and you can set it to a default like `Control@50`. Also add some output variables, all strings. `O_mysql_install`, `O_original_password`, and `O_target_id`. We will use them later
10.  Now in the new group, we want to run these two commands via terminal, so add them in one activity:
```bash
grep "A temporary password" /var/log/mysqld.log
chkconfig mysqld on
```
11.  We can use regex or string activities to get data out of our terminal outputs, so let's try getting the password out! Bring in a `Match Regex` activity. Set the expression to `root@localhost:.*` and then pass in the output of the terminal activity before it as the input string.
12.  We will use a little python script to parse out the full password. So use a python activity with a script similar to the below. Have the input be the 0th element of the previous regex. Have the output be `password` of type `string`.
```python
import sys
input_string = str(sys.argv[1])
colon = input_string.find(":")
password = input_string[colon+2:]
```
13. Use a set variable activity to save that password to the `O_original_password` output string you made earlier. We will not use it, but just save it. 
14. Now we need to do a few more things, but we can do them all at once! We need to set the root password to our input variable, allow any host to connect to our DB, and restart the DB. So input these as commands in a new terminal activity:
```bash
systemctl stop mysqld
systemctl set-environment MYSQLD_OPTS="--skip-grant-tables"
systemctl start mysqld
mysql -u root
FLUSH PRIVILEGES;
ALTER USER 'root'@'localhost' IDENTIFIED BY '<VARIABLE REFERENCE TO INPUT PASSWORD>';
update mysql.user SET HOST='%' WHERE user='root';
FLUSH PRIVILEGES;
exit
systemctl stop mysqld
systemctl unset-environment MYSQLD_OPTS
systemctl start mysqld
```

15. One thing you will have to add is to change the `Individual Command Timeout` to `90` seconds and then add a `Succeeded` expects of `mysql>`. This will allow AO to know that when it sees a mysql prompt it can continue.
16. **NOTE: ONLY 1 PERSON IN YOUR POD TEAM SHOULD RUN THE WORKFLOW** Select your 1 person to run the workflow, run it, and then watch it go. Check the outputs of your different terminal activities to see what they are doing. 
17. After the workflow has completed, you should have a fully installed and `partially` configured DB. (We will investigate more later)
18. If you are not already, terminal into your google linux server. Login to mysql with `mysql -u root -p` and when it prompts for the password, use the one you gave when you ran the workflow.
19. You should be logged into your working mysql instance!

------------- Optional-----------------
# Create a workflow that populates data into MySQL and then queries it
1.  Now let's use our new mysql target!
2.  First, let's create a basic table in MySQL. Login to your mysql instance with root access. Then type `use mysql;` to switch to the mysql DB.
3.  Now run this command to create your table...
```mysql
CREATE TABLE IF NOT EXISTS <cec-id>_tasks (
    task_id INT AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    start_date DATE,
    due_date DATE,
    priority TINYINT NOT NULL DEFAULT 3,
    description TEXT,
    PRIMARY KEY (task_id)
);
```
4.  Create a new workflow called `name_test_mysql_target`. 
5.  Look for the `Insert into Table via JDBC` activity. Drag and drop one onto your canvas.
6.  Select one of your mysql targets. Then drop an insert statement in like this:
```mysql
INSERT INTO <cec-id>_tasks(title,priority)
VALUES('Learn MySQL INSERT Statement',1);
```
7.  Add 2 insert statements like these:
```mysql
INSERT INTO <cec-id>_tasks(title, start_date, due_date)
VALUES('Insert date into table','2018-01-09','2018-09-15');

INSERT INTO <cec-id>_tasks(title,start_date,due_date)
VALUES('Use current date for the task',CURRENT_DATE(),CURRENT_DATE())
```
8.  Now look for the `Select from Table via JDBC`. Drop one below the inserts. Add this query to the select activity `SELECT title, start_date, due_date, priority FROM tasks;`
9.  Check `Persist Table` and add each column from the query under the `Columns to Read`. They can all be strings.
10.  Run your workflow. Check out the results of your select statement after the inserts. Run the same select query in mysql and verify the results.
11.  Spend 15-30 minutes playing with your new MySQL JDBC and/or terminal activities. 

