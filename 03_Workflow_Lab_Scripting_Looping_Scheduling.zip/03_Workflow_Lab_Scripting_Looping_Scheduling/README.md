# Add scripting and run some conditions

This lab will take you through some general components and usage of workflow authoring in AO. The assumption will be after you do a task in AO that you will understand how to do it going forward. So when new tasks or concepts are introduced, they will be closely detailed. If you have to do that same tasks again later it will not.

# Table of Contents
*  Add Scripting and Conditionals
*  Write it out, Email, and Schedules

# Tasks
3.  Do some Scripting
4.  Run Conditionals on the data
5.  Write it out to OSes
6.  Run it every hour
7.  Email yourself the results

# Setup
1.  Use and edit the workflow created in the earlier lab. 

# Add Scripting and Conditionals
1.  Search for `Python` in the toolbox. The first one is for Python 3.X based scripts and the 2nd one is for Python 2.X based. Let's use the 3.x based.
2.  Drag and drop the `EXECUTE PYTHON SCRIPT` block below your JSON Path Query. Add a `SCRIPT ARGUMENT` and point it at `Activites->JSONPAth Query->JSonPath Queries->name`.
3.  Add a `SCRIPT OUTPUT VARIABLE`. Make the `script variable` be `output` and make the `property name` be `name_of_person`. It should be of type `string`. The script variable is the variable name you will use in the python script. The property name is what you will then use in AO to access its value.  
4.  Add this python script to the `script to execute on target`...
```python
import json
import sys

try:
    block = json.loads(sys.argv[1])
    if block['name']:
        output = block['name']
    else:
        output = "No Name Found."
except:
    output = "No Name Found"
```
5.  Go the middle icon in your toolbox, this is the Program Logic or Flow Control area.
6.  Find the `CONDITION BLOCK` and drag and drop it below your `Python Script`.
7.  Click the `CONDITION BLOCK` in your canvas and change the Display Name to `If found name`.
8.  Click on the left most `CONDITION BRANCH` and you should see the conditional dialog.
9.  Under `CONDITION`, title it `THEN`, then select the insert variable reference icon for the first field and map it to `Activity->JSONPath Query->Succeeded`. This is a boolean value that tells us if the activity succeeded or not. Select `Equals` in the second field and then type `true` into the last field.
10.  Click on the other `CONDITION BRANCH`, and do the same as #5, but set the last field to `false`. Title this block `ELSE`. This will work because the JSONPath query activity will error if it does not find what you are looking for.

# Write it out, Email, and Schedules
1.  Create a new varible of type `STRING` called `results`. Make it `local`. 
2.  Under your `THEN` branch, add a `SET VARIABLE` activity and set your `results` string to be. `We found <name> by their username <username>`. The name will be the output from the python script. The username will be the input we passed into the workflow.
3.  Can you do this on your own???? Try it and see if you can do it!
4.  Next we will add a linux target and a windows target (from the workflow UI) to allow us to write out our results. 
5.  Search for `Write` as an acitivity. You should see them in the Linux and Windows adapters. *NOTE*: For write file activities, the file names must be the full file path+file nam
6.  Drag and drop the Linux based `WRITE FILE` and create a target. Select `Override Worklow Target` and then `ADD NEW`. You can call it `LinuxVM_<<name>>`. Add a new account keys, `username` is `telconetuser` and use `private key file attached`. Back to the target, Hostname is `34.139.227.167`. Leave the rest the defaults.
7.  On the `WRITE FILE` activity, set the `file name` to be `/home/telconetuser/<yourname>-basic-workflow-results.txt`. Set the `file content` to be the `results` variable and set it to `Append Existing File`.
8.  Search for the `EMAIL` activity. Drag and drop it into the left `CONDITION BRANCH` blocks.
9.  On the email activity, go to `Target` and select `Override Workflow Target`. Select your SMTP server.
10.  Scroll down and input your email into the `TO` field. Input something into the `SUBJECT` line and add your `results` variable as the message. 
11.  Search for the `GROUP` block, under `LOGIC`. Drag and drop it above all your activities in the `THEN` block. Drag all your activities into that new `GROUP` block. 
12.  On your group block, click the `...` and select `duplicate`. Drag the duplicate over to the other `CONDITION BRANCH`. (Your `else` branch)
13.  Change the `VARIABLE NEW VALUE` in your `SET VARIABLE` activity to reflect that you did not find the person. 
14.  Validate and run the workflow. Search for `bill`. Did it email you? Now run again and search for `Bret`.
15.  Click the "X" on your workflow. Now go to the `Schedules` area. Click `NEW SCHEDULE`.
16.  Make the display name be `hourly`. Select `Daily` for `CALENDAR`, and leave `TIMEZONE` as `UTC`. 
17.  Set the `START TIME` to `12:00AM`, `NUMBER OF RUNS PER DAY` to `23`, and `TIME INTERVAL` to `1 hour/0 min`.
18.  Go back to your workflow. Click `ADD TRIGGER` under `Triggers`. Give it a name like `hourly`. Select your hourly schedule in the `SCHEDULE` drop down and click SAVE.
19. Yous instrutor will be able to show your the executions on the top of every hour.

