# Basic Workflow Lab

This lab will take you through some general components and usage of workflow authoring in AO. The assumption will be after you do a task in AO that you will understand how to do it going forward. So when new tasks or concepts are introduced, they will be closely detailed. 

# Table of Contents
*  Create a Basic Workflow

# Tasks
1.  Create a simple workflow
2.  Use a "Format Date" activity.
3.  Use a sleep command.
4.  Create an output variable.
5.  Set the value of date time activity into output variable.

# Setup
1.  Create a category under `Admin->Categories` and use "<<your name>>-Training" as the category.

# Create a Basic Workflow
1.  Create a new workflow under `Workflows`. Click `NEW WORKFLOW`. Go down the right side and select your category under the `CATEGORY` drop down. If you do not see the desired category, create one and assign. 
2.  Give a name to your workflow for example "Training_Lab_01"
3.  Under `Variables` click `ADD VARIABLE`. 
4.  Select `Data Type` as `Date Time`. `Display Name` as `Formatted Date` and `SCOPE` as `Output`and SAVE.
5.  Continue down to `Target`. Select `No Target` 
6.  On the left side, or Toolbox, search for the `Sleep` activity. Drag and Drop the `Sleep` activity into the middle of your canvas so it "hooks" in.
7.  Click on the `Sleep` activity and set it to 30 seconds in the `SLEEP INTERVAL` field. 
8.  Click `VALIDATE` at the top of the page. Then click `RUN`. 
9.  Observe that the workflow pauses for 30 secs since we gave a sleep command for 30 and completes.
10. After your workflow runs, look at the left side menu. You are in a different area now called `RUNS`. This is where all workflow executions will show. Click on "Workflows" menu on the top left to get back to workflow developmet screen. Search for your workflow.
10. To continue with the lab, click on the workflow name to go back to editing your workflow.
11. Now from the left Toolbox, search for `Format Date` activity. Drag and drop the `Format Date` onto the canvas so it hooks in on top of the `Sleep` activity.
12. Now change the name of the activity to `Date to Format and show`.
13. Continue down to Format Date and select a format, for example select `02-01-2018`.
14. For the original date time, Select the Browse Variables button at the right corner of the Original Date Time text box. Select `Workflow` -> `Output` -> `Start time.`
15. Click `VALIDATE` at the top of the page. Then click `RUN`. 
16. In the execution screen, the first activity which is a Date Time activity completes in a sec and when you scroll down to `Output` section, you should observe the `Result` value show current date in above requested format.
17. The workflow will still be in execution mode because the sleep activity is still in running state for 30 secs(or what ever time duration is selected above.)
18. Finally after that duration observe both the activities shows green and the workflow status changes to `Success`