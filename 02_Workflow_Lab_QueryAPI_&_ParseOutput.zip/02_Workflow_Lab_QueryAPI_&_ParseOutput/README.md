# Basic Workflow Authoring Lab
This lab will take you through some general components and usage of workflow authoring in AO. The assumption will be after you do a task in AO that you will understand how to do it going forward. So when new tasks or concepts are introduced, they will be closely detailed. If you have to do that same tasks again later it will not.

# Table of Contents
*  README.md
*  Create a Basic Workflow
*  Add HTTP Activity
*  Handle the Output and make it Atomic

# Tasks
1.  Query an API.
2.  Parse the data.

# Setup
1.  Create a runtime user under `Account Keys`. Click `NEW ACCOUNT KEY`, select `HTTP Basic Authentication` and fill out the information. The actual information does not matter. You can use `test/test` if you like. Click SUBMIT.
2.  Create a target under `Targets`. Click `NEW TARGET`, select HTTP Endpoint and fill out the information. Set `DEFAULT ACCOUNT KEYS` to your user from #1. Select `HTTPS` protocol. Set the `HOST/IPADDRESS` to `jsonplaceholder.typicode.com`. Set the `PORT` to `443` and select `DISABLE SERVER CERTIFICATE VALIDATION`. Click SUBMIT.

# Create a Basic Workflow
1.  Create a new workflow under `Workflows`. Click `NEW WORKFLOW`. Go down the right side and select your category under the `CATEGORY` drop down. 
2.  Under `Variables` click `ADD VARIABLE`. 
3.  For the first variable Select `Data Type` as `String`. `Display Name` as `path` and `SCOPE` as `Input`. Set the value or default as `users`. Make it `required`. CLick SAVE.
4.  Click `ADD VARIABLE` again. Select `Data Type` as `String`. `Display Name` as `output json` and `SCOPE` as `Output`. Click SAVE.
5.  Continue down to `Target`. Select `Execute On This Target` and then select `HTTP Endpoint` under the `TARGET TYPE` drop down and then select your target under the `TARGET` drop down. 
6.  Search for `http` in your toolbox and drag and drop the `HTTP Request` activity. This is the basic activity to make any API call. 
7.  Click on the `HTTP Request` activity. Change the `DISPLAY NAME` to `GET JSONPATH`.
8.  Scroll down to `RELATIVE URL`. Click the puzzle-piece icon(or insert variable reference) and a new dialog should appear called `Browse Variables`.
9.  Click `Workflow`, then `Input`, then you should see your `path` variable. Click it and then click SAVE. You should now see a VARIABLE REFERENCE showing in your `RELATIVE URL` field.
10.  Set `METHOD` to `GET`. Scroll down and set the `CONTENT TYPE` to `JSON`. Validate the workflow and run it. Select your target and leave path as the default. What happens? Insepct the results!

# Handle the Output and make it Atomic
1.  Go back to editing your workflow after running it.
2.  Search for the `Set Variables` activity. Drag and drop it BELOW your `GET JSONPATH` activity. Change the `DISPLAY NAME` to `Set Output`
3.  Click `ADD`. For `VARIABLE TO UPDATE`, click the insert variable reference icon, and browse to your output variable. `Workflow->Output->output json`. Click SAVE.
4.  For `VARIABLE VALUE NEW`, click the insert variable reference icon. Now browse to `Activities`, then your activity `GET JSONPATH`, then select `Body`. Click SAVE.
5.  Create a new variable of type `Integer` and call it `Status Code`. It should be an `output` scope. See if you can do this on your own!
6.  Add your new variable to the `Set Output` activity. Click `ADD` below your first entry and set your `Status Code` Variable to the value in `Activities->GET JSONPATH->Status code`. See if you can do this yourself!
7.  Validate the workflow and run it. See what your variables are set to.
8.  Go back to editing your workflow. Scroll down and select the checkbox next to `IS ATOMIC WORKFLOW`. 
9.  `GROUP NAME` should now be selectable. Type in your NAME into it and click `create`. 
10.  Validate it. Can you still run it? What does the mean for development and usage?
11.  Exit the workflow... did it disappear??? Look under `Atomic Workflows` instead of `My Workflows`. 

# JSON Path query and run condition.
1.  Create a new workflow called `Master`. 
2.  Scroll down and select `Execute On This Target`. Select `HTTP ENDPOINT` as the `TARGET TYPE` and then select your JSONPATH holder target in the `TARGET` select.
3.  Click on the Workflow Icon in the toolbox area. This is the most right icon. Do you see your first workflow? Why or why not?
4.  Try looking in the Activities section which is the most left icon. (The one we used before). Is it there? Look for your NAME.
5.  Drag and drop your workflow to your canvas. It should look a little different. 
6.  Add an `input` variable call `name` of type `string`. Make it `required`.
7.  Find the `JSONPath Query` activity. Drag and drop it below your atomic workflow in the MASTER workflow.
8.  On the `JSONPath Query` activity, click insert variable reference and point it to the output of your previous activity. This should be `Activites->Your Activity->output json`.
9.  Scroll down and click `ADD` below `JSONPATH QUERIES`. Leave the `PROPERTY TYPE` as `String`. Make the `PROPERTY NAME` be `name` and make the `JSONPATH QUERY` be `$.[?(@.username=="<input name>")]`. How do you think you can do this? Can you put a variable and text in the same field?
10.  Select the checkbox for `CONTINUE WORKFLOW EXECUTION ON FAILURE`.
