# Exporting workflow to git
This lab will help understand on how to export a workflow externally to a git repo and import to a destination env when needed.

# Table of Contents
*  Git Integration

# Tasks
1.  Git Integration
2.  Save workflow to git.

# Setup
Use the workflow created in earlier lab exercise. 
Create a Github account and commit the workflow export to git.

# Git Integration
1. Let's export it! Go to https://github.com
2. Create a new user account or login with an existing account.
3. Click New Repository after logging in.
4. Call it `ao-workflows` and make it public
5. Create a blank README in it
6. In AO, go to `Admin->integrations->Git Repositories`
7. Click `NEW GIT REPOSITORY`, and give it a name like `<<Name>>-my workflow repo`
8. For the `ACCOUNT KEY` select new and create the user with your username and password you used while logging on to GIT.
9. Select the `PROTOCOL` as `HTTPS`, `TYPE` as `GitHub`, `REST API` as `https://github.com/Sxotelconet/` and `BRANCH` as `Master`. Click SAVE.
10. Go back to your `MASTER` workflow. Under the `VERSION` header select the new repo you just made.
11. Click `VALIDATE` and then click `COMMIT` and give it a commit message and click SUBMIT. 
12. After it exports, go to your repo and check it out. What format do you see? 
13. Go back to your workflow and check out the versioning info as well!
